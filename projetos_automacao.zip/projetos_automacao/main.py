import pandas as pd
from twilio.rest import Client

# Your Account SID from twilio.com/console
account_sid = "AC42e9b67404ca89e7f7eae285d845713e"
# Your Auth Token from twilio.com/console
auth_token  = "6ae135857c32889c21f197c93cf61c66"
client = Client(account_sid, auth_token)
 


#Abrir os seis arquivos e exceel
lista_meses={'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho'}
for mes in lista_meses:
    tabela_vendas = pd.read_excel(f'{mes}.xlsx')
    if (tabela_vendas['Vendas'] > 55000).any():
       
        vendedor = tabela_vendas.loc[tabela_vendas['Vendas'] > 55000,'Vendedor'].values[0]
        vendas= tabela_vendas.loc[tabela_vendas['Vendas'] > 55000, 'Vendas'].values[0]
        print(f'no mês {mes} encontrou alguém bateu a meta. Vendedor: {vendedor} , Vendas: {vendas} ')
    message = client.messages.create(
    to="+5511949560689", 
    from_="+14092316854",
    body= f'no mês {mes}  alguém bateu a meta. Vendedor: {vendedor} , Vendas: {vendas} ')

print(message.sid)    

   







#Para Cada Arquivo:

#Verificar (se algum valor na coluna de vendas naquele arquivo é maior que 55 mil)

#Se for maior que 55 mil (--> envia um sms com nome , o mês e as vendas do vendedor)

#Caso 
# não seja maior que 55 mil --> (Não quero fazer nada)


